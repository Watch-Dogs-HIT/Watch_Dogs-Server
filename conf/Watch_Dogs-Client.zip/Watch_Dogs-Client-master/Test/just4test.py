import time

i = 0

while 1:
    time.sleep(5)
    print i
    print 1
