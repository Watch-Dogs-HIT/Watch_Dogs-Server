#!/usr/bin/env python
# encoding:utf8

"""
flask 异步demo
"""
