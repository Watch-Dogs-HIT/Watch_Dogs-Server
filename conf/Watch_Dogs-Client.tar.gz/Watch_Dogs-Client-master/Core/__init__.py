#!/usr/bin/env python
# encoding:utf-8


"""
系统监控核心功能实现

Note:

1. CPU信息中时间片的单位是jiffies,jiffies记录了系统启动以来，经过了多少tick=5ms。
https://www.cnblogs.com/arnoldlu/p/7234443.html
"""
